package com.javabrains;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaBrainSpringSecurityJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaBrainSpringSecurityJwtApplication.class, args);
	}

}
